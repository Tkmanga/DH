<?php
include_once("Persona.php");
/**
 *
 */
interface Liquidable
{
  public function liquidarHaberes(Persona $var,$var2);
}

 ?>
