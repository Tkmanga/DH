<?php
 /**
 *
 */
abstract class Record
{

}

 ?>
