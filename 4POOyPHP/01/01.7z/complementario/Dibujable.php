<?php

/**
 *
 */
interface Dibujable
{
  public function dibujar();
}


 ?>
