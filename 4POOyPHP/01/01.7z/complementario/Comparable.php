<?php
/**
 *
 */
interface Comparable
{
  public function equals($objB);
}

 ?>
