<?php
/**
 *
 */
class CalculadoraEnteros
{
  public function operacion($val)
  {
    return round($val,0,PHP_ROUND_HALF_DOWN);
  }

}


 ?>
