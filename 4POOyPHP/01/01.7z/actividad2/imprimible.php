<?php
/**
 *
 */
interface Imprimible
{
  public function mostrar();
}

 ?>
