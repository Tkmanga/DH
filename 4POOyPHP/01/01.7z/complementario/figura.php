<?php
 /**
 *
 */
abstract class Figura
{
  public abstract function getPerimetro();
  public abstract function getArea();
}


 ?>
